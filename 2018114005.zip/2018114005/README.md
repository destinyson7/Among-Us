# Computer Graphics
## Assignment 1
## Among Us Clone

### Running the Code

- Unzip the code and add the required libraries given in the CMakeLists.txt.

- Make a separate directory named libraries outside the source directory and put glad and glfw inside it. Put glm in the includes (usr/includes) folder.

- Run the following commands
  	```
	mkdir build
	cd build
	cmake ..
    make
    ./assignment-1
	```

### Assignment by:
- Tanish Lad
- Roll Number: 2018114005
